document.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        // تشغيل الصوت
        var sound = document.getElementById("firework-sound");
        sound.play();
        var applauseSound = document.getElementById("applause-sound");
        applauseSound.play();

        // تحديث نص العنصر h1
        var message = document.getElementById("message");
        message.textContent = "Congratulations!";
        
        // إعدادات الألعاب النارية
        var duration = 5 * 1000;
        var end = Date.now() + duration;

        (function frame() {
            confetti({
                particleCount: 3,
                angle: 60,
                spread: 55,
                origin: { x: 0 }
            });
            confetti({
                particleCount: 3,
                angle: 120,
                spread: 55,
                origin: { x: 1 }
            });

            if (Date.now() < end) {
                requestAnimationFrame(frame);
            }
        }());
    }
});

